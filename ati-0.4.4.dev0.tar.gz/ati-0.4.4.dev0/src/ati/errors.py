# -*- coding: utf-8 -*-
"""Error classes for ati."""


class InvalidRemoteError(Exception):
    """When data is invalid for the chosen remote."""
    pass
