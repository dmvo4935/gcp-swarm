# -*- coding: utf-8 -*-
import pkg_resources

__version__ = pkg_resources.get_distribution("ati").version
__name__ = pkg_resources.get_distribution("ati").project_name
